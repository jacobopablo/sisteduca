<?php
session_start();
if (!isset($_SESSION['nombre'])) {
  header("Location: login.html");
}else{

 
require 'header.php';

if ($_SESSION['acceso']==1) {
$user_id=$_SESSION["idusuario"];
  require_once "../modelos/Consultas.php";
  $consulta = new Consultas();
  $rsptav = $consulta->cantidadalumnos($user_id);
  $regv=$rsptav->fetch_object();
  $totalestudiantes=$regv->total_alumnos;
  $cap_almacen=3000;

 ?>
    <div class="content-wrapper">
    <!-- Main content -->
    <section class="content">

      <!-- Default box -->
      <div class="row">
        <div class="col-md-12">
      <div class="box">
          <div class="box-header with-border">
              <h1 class="box-title">Ingresa tu Proyecto</h1>
              <p> <?php echo $_SESSION['nombre']; ?></p>

          <div class="box-tools pull-right">
        <!--box-header-->

<!--fin centro-->
      </div>
      </div>
      </div>


<div class="panel-body" id="formularioregistros">
  <form action="" name="formulario" id="formulario" method="POST">
    <div class="form-group col-lg-9 col-md-10 col-xs-12">
      <label for="">Nombre del Proyecto(*):</label>
      <input class="form-control" type="hidden" name="idusuario" id="idusuario">
      <input class="form-control" type="text" name="nombre" id="nombre" maxlength="100" placeholder="Nombre" required>
    </div>
    <div class="form-group col-lg-10 col-md-10 col-xs-12">
      <label for="">Descripción del Proyecto(*):</label>
      <input class="form-control" type="hidden" name="idusuario" id="idusuario">
      <input class="form-control" type="text" name="nombre" id="nombre" maxlength="100" placeholder="Nombre" required>
    </div>
    <div class="form-group col-lg-10 col-md-6 col-xs-12">
      <label for="">Ubicación(*):</label>
     <select name="tipo_documento" id="tipo_documento" class="form-control select-picker" required>
       <option value="DNI">DNI</option>
       <option value="RUC">RUC</option>
       <option value="CEDULA">CEDULA</option>
     </select>

     <label for="">Provincia(*):</label>
     <input class="form-control" type="text" name="nombre" id="nombre" maxlength="100" placeholder="Nombre Provincia" required>
     <label for="">Distrito(*):</label>
     <input class="form-control" type="text" name="nombre" id="nombre" maxlength="100" placeholder="Nombre Distrito" required>
     <label for="">Comunidad(*):</label>
     <input class="form-control" type="text" name="nombre" id="nombre" maxlength="100" placeholder="Nombre Comunidad" required>
    </div>
    <div class="form-group col-lg-10 col-md-6 col-xs-12">
      <label for="">Descripción del proyecto(*):</label>
      <input type="text" class="form-control" name="num_documento" id="num_documento" placeholder="Documento" maxlength="20">
    </div>

    <div class="form-group col-lg-6 col-md-10 col-xs-12">
      <label for="">Duración del Proyecto(*):</label> 
      <br>
      <label for="">Fecha de Inicio</label>
      <input class="form-control" type="text" name="telefono" id="telefono" maxlength="20" placeholder="Ingresar Fecha">
      <label for="">Fecha de Termino </label>
      <input class="form-control" type="text" name="telefono" id="telefono" maxlength="20" placeholder="Ingresar Fecha">
      <label for="">Total Meses Dias</label>
      <input class="form-control" type="text" name="telefono" id="telefono" maxlength="20" placeholder="Ingresar">
    </div>
    <div class="form-group col-lg-10 col-md-6 col-xs-12">
      <label for="">Organización Ejecutora</label>
      <input class="form-control" type="text" name="direccion" id="direccion"  maxlength="70">
    </div>
    <div class="form-group col-lg-6 col-md-6 col-xs-12">
      <label for="">Destinatario o Beneficiarios</label>
      <input class="form-control" type="text" name="telefono" id="telefono" maxlength="20" placeholder="Número de telefono">

        <div class="panel-body table-responsive" id="listadoregistros">
            <table id="tbllistado" class="table table-striped table-bordered table-condensed table-hover">
        <thead>
              <th>Directos</th>
              <th>Indirectos</th>
              <th>Usuario</th>
        </thead>
        <tbody>
        </tbody>
        <tfoot>
              <th>Opciones</th>
              <th>Nombre</th>
              <th>Usuario</th>
        </tfoot>   
        </table>
        </div>
    </div>

    <div class="panel-body" style="height: 400px;" id="formularioregistros">
  <form action="" name="formulario" id="formulario" method="POST">
    <div class="form-group col-lg-6 col-md-6 col-xs-12">
      <label for="">Nombre</label>
      <input class="form-control" type="hidden" name="idgrupo" id="idgrupo">
      <input class="form-control" type="text" name="nombre" id="nombre" maxlength="50" placeholder="Nombre" onKeyUp="document.getElementById(this.id).value=document.getElementById(this.id).value.toUpperCase()" required>
    </div>
        <div class="form-group col-lg-12 col-md-12 col-xs-12">
    </div>
  <div class="form-group col-lg-4 col-md-4 col-xs-6">
                <div class="checkbox">
                  <label>
                    <input type="checkbox" name="favorito" id="favorito" value="1"> Favorito
                  </label>
                </div>
                </div>

    <div class="form-group col-lg-12 col-md-12 col-sm-12 col-xs-12">
      <button class="btn btn-primary" type="submit" id="btnGuardar"><i class="fa fa-save"></i>  Guardar</button>
      <button class="btn btn-danger" onclick="cancelarform()" type="button" id="btnCancelar"><i class="fa fa-arrow-circle-left"></i> Cancelar</button>
    </div>
  </form>
</div>
    
    <div class="form-group col-lg-6 col-md-6 col-xs-12">
      <label for="">Email: </label>
      <input class="form-control" type="email" name="email" id="email" maxlength="70" placeholder="email">
    </div>
    <div class="form-group col-lg-6 col-md-6 col-xs-12">
      <label for="">Cargo</label>
      <input class="form-control" type="text" name="cargo" id="cargo" maxlength="20" placeholder="Cargo">
    </div>
    <div class="form-group col-lg-6 col-md-6 col-xs-12">
      <label for="">Login(*):</label>
      <input class="form-control" type="text" name="login" id="login" maxlength="20" placeholder="nombre de usuario" required>
    </div>
    <div class="form-group col-lg-6 col-md-6 col-xs-12" id="claves">
      <label for="">Clave(*):</label>
      <input class="form-control" type="password" name="clave" id="clave" maxlength="64" placeholder="Clave">
    </div>
    <div class="form-group col-lg-6 col-md-6 col-xs-12">
      <label>Permisos</label>
      <ul id="permisos" style="list-style: none;">
        
      </ul>
    </div>
        <div class="form-group col-lg-6 col-md-6 col-xs-12">
      <label for="">Archivo:</label>
      <input class="form-control" type="file" name="imagen" id="imagen">
      <input type="hidden" name="imagenactual" id="imagenactual">
      <img src="" alt="" width="150px" height="120" id="imagenmuestra">
    </div>
    <div class="form-group col-lg-12 col-md-12 col-sm-12 col-xs-12">
      <button class="btn btn-primary" type="submit" id="btnGuardar"><i class="fa fa-save"></i>  Guardar</button>
      <button class="btn btn-danger" onclick="cancelarform()" type="button"><i class="fa fa-arrow-circle-left"></i> Cancelar</button>
    </div>
  </form>
</div>

<!--fin centro-->

<!--fin centro-->
      </div>
      </div>
      </div>
      <!-- /.box -->

    </section>
    <!-- /.content -->
  </div>
<?php 
}else{
 require 'noacceso.php'; 
}

require 'footer.php';
 ?>

 <?php 
}

ob_end_flush();
  ?>